#!/usr/bin/env python3
"""Independently verify APK Signature Scheme v2 signatures/content digests.
Only reads existing APK bytes. Uses cryptography and standard library.
"""
import struct,hashlib,sys,os,glob,json
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa,padding,ec,dsa
U32=lambda b,o:struct.unpack_from('<I',b,o)[0]
U64=lambda b,o:struct.unpack_from('<Q',b,o)[0]
def lp(b,o):
 if o+4>len(b):raise ValueError('short length prefix')
 n=U32(b,o);o+=4
 if n>len(b)-o:raise ValueError('length prefix exceeds buffer')
 return b[o:o+n],o+n
def all_lp(b):
 out=[];pos=0
 while pos<len(b):
  nxt,pos=lp(b,pos);out.append(nxt)
 return out
SIGALGS={0x0101:('sha256','pss'),0x0102:('sha512','pss'),0x0103:('sha256','pkcs1'),0x0104:('sha512','pkcs1'),0x0201:('sha256','ecdsa'),0x0202:('sha512','ecdsa'),0x0301:('sha256','dsa')}
def verify(path):
 fsz=os.path.getsize(path)
 with open(path,'rb') as f:
  f.seek(max(fsz-65557,0));tail=f.read();ix=tail.rfind(b'PK\x05\x06')
  if ix<0:raise ValueError('EOCD missing')
  eocd=tail[ix:];cd=U32(eocd,16)
  f.seek(cd-24);end=f.read(24)
  if end[8:]!=b'APK Sig Block 42':raise ValueError('APK v2 signature block missing')
  blocksz=U64(end,0);start=cd-blocksz-8
  f.seek(start);pairblock=f.read(blocksz+8)
  if U64(pairblock,0)!=blocksz:raise ValueError('signature block size mismatch')
  pos=8;sigblock={}
  while pos<len(pairblock)-24:
   plen=U64(pairblock,pos);id=U32(pairblock,pos+8)
   sigblock[id]=pairblock[pos+12:pos+8+plen]
   pos+=plen+8
  vb=sigblock[0x7109871a]
  signers=all_lp(lp(vb,0)[0]);out=[]
  for signer in signers:
   signed,o=lp(signer,0);sigs,o=lp(signer,o);spki,o=lp(signer,o)
   digests,o=lp(signed,0);certs,o=lp(signed,o);attrs,o=lp(signed,o)
   cert_list=[x509.load_der_x509_certificate(c) for c in all_lp(certs)]
   cert=cert_list[0]
   pub=serialization.load_der_public_key(spki)
   signatures={U32(x,0):lp(x,4)[0] for x in all_lp(sigs)}
   digests={U32(x,0):lp(x,4)[0] for x in all_lp(digests)}
   matching=[]
   for alg in signatures:
    if alg not in SIGALGS: continue
    digest,method=SIGALGS[alg]
    h=hashes.SHA256() if digest=='sha256' else hashes.SHA512()
    try:
     if method=='pss':pub.verify(signatures[alg],signed,padding.PSS(mgf=padding.MGF1(h),salt_length=h.digest_size),h)
     elif method=='pkcs1':pub.verify(signatures[alg],signed,padding.PKCS1v15(),h)
     elif method=='ecdsa':pub.verify(signatures[alg],signed,ec.ECDSA(h))
     elif method=='dsa':pub.verify(signatures[alg],signed,h)
     else:continue
     matching.append((alg,digest))
    except Exception as e:pass
   if not matching:raise ValueError('no valid signed-data signature')
   for alg,digest in matching:
    if alg not in digests:continue
    hf=lambda data:hashlib.new(digest,data)
    nchunks=0;chunkhashes=[]
    # For a content digest, hash chunks of signed sections: before signing block,
    # central directory, and EOCD rewritten to point at the signing block's start.
    def update_chunks(chunks):
     nonlocal nchunks
     for part in chunks:
      nchunks+=1
      chunkhashes.append(hf(b'\xa5'+struct.pack('<I',len(part))+part).digest())
    f.seek(0)
    remaining=start
    def prefix():
     nonlocal remaining
     while remaining:
      piece=f.read(min(1048576,remaining));remaining-=len(piece)
      if not piece:raise ValueError('truncated APK prefix')
      yield piece
    update_chunks(prefix())
    f.seek(cd)
    remaining=U32(eocd,12)
    def central():
     nonlocal remaining
     while remaining:
      piece=f.read(min(1048576,remaining));remaining-=len(piece)
      if not piece:raise ValueError('truncated central directory')
      yield piece
    update_chunks(central())
    modified=bytearray(eocd);struct.pack_into('<I',modified,16,start)
    update_chunks([bytes(modified)])
    actual=hf(b'\x5a'+struct.pack('<I',nchunks)+b''.join(chunkhashes)).digest()
    if actual != digests[alg]: raise ValueError('APK content digest mismatch')
    out.append({'algorithm':hex(alg),'digest':digest,'signed_data_valid':True,'content_integrity_valid':True,'certificate_sha256':cert.fingerprint(hashes.SHA256()).hex(),'signer_subject':cert.subject.rfc4514_string()})
  return out
if __name__=='__main__':
 result={}
 for p in sorted(glob.glob('/mnt/data/*.apk')):
  try:result[os.path.basename(p)]={'status':'PASS','signatures':verify(p)}
  except Exception as e:result[os.path.basename(p)]={'status':'FAIL','reason':str(e)}
  print(os.path.basename(p)[:100], result[os.path.basename(p)])
 with open('/mnt/data/messenger_apk_integrity.json','w') as f:json.dump(result,f,indent=2)
