#!/usr/bin/env python3
"""Read-only DEX string index keyword scout, without loading executable code."""
import zipfile,glob,struct,collections,json,re,os
from pathlib import Path
U32=lambda b,o: struct.unpack_from('<I',b,o)[0]
def uleb(b,p):
 x=0
 for i in range(5):
  v=b[p];p+=1;x|=(v&127)<<(7*i)
  if not v&128:break
 return p
def dex_strings(data):
 if data[:4]!=b'dex\n':return []
 n=U32(data,56);off=U32(data,60)
 for i in range(n):
  so=U32(data,off+i*4);sstart=uleb(data,so); end=data.find(b'\x00',sstart)
  if end!=-1:yield data[sstart:end].decode('utf-8','replace')
patterns=['encryption','encrypt','signal','labyrinth','e2ee','securestorage','secure_storage','mqtt','messaging','graphql','omnistore','keytransparency','auth','login','keystore']
def run(p):
 res={'file':Path(p).name,'dex_count':0,'string_total':0,'hit_count':{},'example_strings':{}}
 grouped=collections.defaultdict(list); counts=collections.Counter()
 with zipfile.ZipFile(p) as z:
  for f in z.namelist():
   if re.fullmatch(r'classes\d*\.dex',f):
    res['dex_count']+=1
    for s in dex_strings(z.read(f)):
     res['string_total']+=1
     ss=s.lower()
     for key in patterns:
      if key in ss:
       counts[key]+=1
       if len(grouped[key])<8 and len(s)<240:
        grouped[key].append(s[:180])
 res['hit_count']=dict(counts)
 res['example_strings']=dict(grouped)
 return res
if __name__=='__main__':
 res=[run(p) for p in sorted(glob.glob('/mnt/data/*.apk'))]
 json.dump(res,open('/mnt/data/messenger_dex_symbols.json','w'),indent=2)
 for r in res:
  print('\n'+r['file'][:70]);print('dex count',r['dex_count'],'strings',r['string_total']);print(r['hit_count'])
  for k in ['e2ee','labyrinth','signal','securestorage','keytransparency']:
   print('  ',k, r['example_strings'].get(k,[])[:3])
