# Messenger for Android 4.4 — Stage 2 Tools

This package is **research/diagnostics, not a patched Messenger APK**.
The primary objective is safe and repeatable compatibility engineering for the device reuse charity.

## Requirements

- Python 3.8 or newer (standard library only)
- Windows 10/11, Linux or macOS host
- `adb` (Android Platform Tools) only for the optional real-device probe
- One authorized physical Android 4.4 test device and an account permitted for testing; not required for static tools

## Files

- `MILESTONE_2_MESSENGER_ANDROID44.md` — full milestone results and stopping conditions
- `inspect_superpack.py` — read-only `.spo` manifest parser and independent XZ block scanner
- `dex_api_inventory.py` — DEX method-reference and keyword count comparison
- `compare_410_variants.py` — checks per-ordinal x86 DEX hashes against KitKat archive metadata
- `kitkat_device_probe.py` — optional local ADB version/install/launch diagnostic with no raw log export
- `messenger410_kitkat_superpack_inventory.json` — observed archive data
- `messenger410_variant_dex_comparison.json` — ARM vs x86 hash comparison
- `messenger410x86_vs_588_api_refs.json` — newer Android symbolic reference differences
- `tests/test_tools.py` — standalone parser/privacy classification test fixtures

## Run static scans

```bash
python inspect_superpack.py "path/to/410_minAPI19.apk" --output archive.json
python compare_410_variants.py "path/to/410_minAPI19.apk" "path/to/410_minAPI21_x86.apk" --output comparison.json
python dex_api_inventory.py "path/to/410_minAPI21_x86.apk" "path/to/588_minAPI28.apk" --output framework_refs.json
python -m unittest discover -s tests -v
```

## Probe authorized KitKat device

Enable developer options and USB debugging on the **test device**, install Android Platform Tools on the PC, and allow debugging on-device.

```bash
python kitkat_device_probe.py --output inventory.json
python kitkat_device_probe.py --install "path/to/410_minAPI19.apk" --launch --output attempt.json
python kitkat_device_probe.py --classify-logcat --output error_categories.json
```

The install flag changes the device, the launch flag opens the package. Running without these flags is read-only. The log classifier captures no raw log output on disk and does **not** definitively attribute device-wide errors to Messenger. Use test accounts and never share private message contents or authentication tokens.

## Known limits

- `.spo` XZ parts do not reassemble into runnable DEX files automatically.
- No third-party APK is redistributed in this archive.
- No login/E2EE bypass or cracked signature is supplied.
- No Android 4.4 device was connected to the evaluation environment. Static scans cannot prove current server compatibility.
